<script>
    var label_please_wait = 'Please wait...';
var label_please_select_records_to_delete =
    'Please select records to delete.';
var label_something_went_wrong = 'Something went wrong.';
var label_please_correct_errors = 'Please correct errors.';
var label_project_removed_from_favorite_successfully =
    'Project removed from favorite successfully.';
var label_project_marked_as_favorite_successfully =
    'Project marked as favorite successfully.';
var label_yes = 'Yes';
var label_upload = 'Upload';
var decimal_points = 1;
var label_update = 'Update';
var label_delete = 'Delete';
var label_view = 'View';
var label_not_assigned = 'Not assigned';
var label_delete_selected = 'Deleted selected';
var label_search = 'Search';
var label_create = 'Create';
var label_min_0 = 'Value must be greater then 0';
var label_max_100 = 'Not greater Then 100';

var label_set_as_default_view = 'Set as Default View';
var label_users_associated_with_project = 'Users associated with project';
var label_update_task = 'Update task';
var label_quick_view = 'Quick View';
var label_project = 'Project';
var label_task = 'Task';
var label_projects = 'Projects';
var label_tasks = 'Tasks';
var label_clear_filters = 'Clear Filters';
var label_set_as_default_view = 'Set as Default View';
var label_default_view = 'Default View';
var label_save_column_visibility = 'Save Column Visibility';
</script>
